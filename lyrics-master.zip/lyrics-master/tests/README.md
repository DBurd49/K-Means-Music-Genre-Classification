# Tests for Open Lyrics Database

Automated tests for validating integrity


## How to run tests

    make

or

    make 2> /dev/null

to suppress STDERR (reduces verbosity)
