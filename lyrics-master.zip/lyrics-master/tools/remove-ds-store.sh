#!/bin/sh

find ../database/ -name ".DS_Store" -type f -exec rm -f {} \;
