No one knows permanence quite like you
There’s a ruthlessness in all that you do
This is not about what we deserve
There’s no bias in the misery served

C.A.N.C.E.R

So watch the sun sink into the sea
There is a perfect peace but don’t wait up for me

When we all fade away
And this world can’t bare another day
There will be no fight in broken bliss

I feel it now more than ever
A reaper’s watch, my life ready to sever

Your name carries more than disease
A symbol of man brought to his knees

This is not about what we deserve
There’s no bias in the misery served

C.A.N.C.E.R

Find a little light and hold it close
Don’t lose sight of what matters most

Find a little light and hold it close
Don’t lose sight of what matters most

This is a burden we all carry together
Waiting in the wings, so we never say never

And when we all fade away
And this world can’t bare another day
There will be no fight in broken bliss

So watch the sun sink into the sea
There is a perfect peace but don’t wait up for me

C.A.N.C.E.R
C.A.N.C.E.R

This is a burden we all carry together
Waiting in the wings, so we never say never


___________________
Name    C.A.N.C.E.R
Artist  Architects
Album   Lost Forever ∕∕ Lost Together
