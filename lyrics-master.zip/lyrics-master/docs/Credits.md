Special thanks go to artists who have kindly shared their texts or helped this project in any other way.

Here they are:
 - Michael Arthur Holloway of Dead When I Found Her [[bandcamp](https://deadwhenifoundher.bandcamp.com/)]
 - The Last Internationale [[website](https://www.tlinyc.com/)]
 - Luc Van Acker [[website](http://www.lucvanacker.com/)]
 - Jae Matthews of Boy Harsher [[website](https://boyharsher.com/)]
 - Jean Paul Hare of JK/47 [[bandcamp](https://jaykay47.bandcamp.com/)]
 - Sam HaiNe [[bandcamp](https://samhaine.bandcamp.com/)]
 - Slade Templeton of Crying Vessel [[bandcamp](https://cryingvessel.bandcamp.com/)]

---

The contents of this repository is the result of work performed by many people who willingly took their time to contribute to the project. They did so without being paid, sponsored, or compensated in any way.

The best that can currently be done is to mention their names here:
 - Andy Alt @andy5995
 - Defanor @defanor
 - @egecelikci
 - Martin @C0rn3j
 - Mike Lyou @mikelyou
 - Sunshine @snshn
 - @vanita5
